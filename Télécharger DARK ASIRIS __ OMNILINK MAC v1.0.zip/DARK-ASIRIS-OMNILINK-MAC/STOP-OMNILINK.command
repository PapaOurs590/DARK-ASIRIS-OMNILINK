#!/bin/zsh
cd "$(dirname "$0")"
if [ -f logs/server.pid ]; then
  kill "$(cat logs/server.pid)" 2>/dev/null || true
  rm -f logs/server.pid
fi
pkill -f "tunnel-client run.*dark-asiris-omnilink-mac" 2>/dev/null || true
echo "OMNILINK MAC arrete."

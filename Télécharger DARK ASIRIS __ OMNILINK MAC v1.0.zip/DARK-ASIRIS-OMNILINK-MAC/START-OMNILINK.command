#!/bin/zsh
set -euo pipefail
cd "$(dirname "$0")"
PROFILE="$(cat config/profile-name.txt 2>/dev/null || echo dark-asiris-omnilink-mac)"
export CONTROL_PLANE_API_KEY="$(security find-generic-password -a "$USER" -s DARK_ASIRIS_OMNILINK_RUNTIME_KEY -w)"
if lsof -ti tcp:8000 >/dev/null 2>&1; then
  echo "OMNILINK utilise deja le port 8000."
  exit 1
fi
.venv/bin/python omnilink_server.py > logs/server.log 2>&1 &
SERVER_PID=$!
echo "$SERVER_PID" > logs/server.pid
for i in {1..30}; do
  nc -z 127.0.0.1 8000 >/dev/null 2>&1 && break
  sleep 1
done
if ! nc -z 127.0.0.1 8000 >/dev/null 2>&1; then
  kill "$SERVER_PID" 2>/dev/null || true
  echo "Le serveur MCP ne repond pas. Voir logs/server.log"
  exit 1
fi
echo "DARK ASIRIS // OMNILINK MAC ONLINE"
trap 'kill "$SERVER_PID" 2>/dev/null || true' EXIT INT TERM
./tunnel/tunnel-client run --profile "$PROFILE" --health.listen-addr "127.0.0.1:0" --log.level info --log.format struct-text

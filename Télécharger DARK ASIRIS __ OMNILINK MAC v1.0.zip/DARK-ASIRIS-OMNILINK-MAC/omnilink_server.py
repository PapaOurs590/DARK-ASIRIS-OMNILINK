from __future__ import annotations

import datetime
import hashlib
import json
import os
import platform
import shutil
import subprocess
from pathlib import Path

from mcp.server.fastmcp import FastMCP

ROOT = Path(__file__).resolve().parent
CONFIG = json.loads((ROOT / "config" / "permissions.json").read_text(encoding="utf-8"))
BACKUP_ROOT = ROOT / "backup" / "coding-agent"
LOG_FILE = ROOT / "logs" / "coding-agent.jsonl"
BACKUP_ROOT.mkdir(parents=True, exist_ok=True)
LOG_FILE.parent.mkdir(parents=True, exist_ok=True)

mcp = FastMCP("DARK ASIRIS // OMNILINK MAC", instructions="Controlled local macOS development bridge. Prefer read-only inspection; snapshot before edits.")


def norm(value: str) -> Path:
    return Path(value).expanduser().resolve()


def limited(text: str, limit: int = 30000) -> str:
    return text if len(text) <= limit else text[:limit] + "\n[TRUNCATED]"


def run(exe: str, args: list[str], cwd: str | None = None, timeout: int = 120) -> dict:
    try:
        result = subprocess.run([exe, *args], cwd=cwd, capture_output=True, text=True, timeout=timeout, shell=False)
        return {"ok": result.returncode == 0, "exit_code": result.returncode, "stdout": limited(result.stdout or ""), "stderr": limited(result.stderr or ""), "executable": exe, "arguments": args, "cwd": cwd}
    except subprocess.TimeoutExpired:
        return {"ok": False, "error": "timeout", "timeout_seconds": timeout}
    except Exception as error:
        return {"ok": False, "error": type(error).__name__, "details": str(error)}


def log(action: str, data: dict) -> None:
    record = {"time": datetime.datetime.now(datetime.timezone.utc).isoformat(), "action": action, "data": data}
    with LOG_FILE.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(record, ensure_ascii=False) + "\n")


def safe_text(path: Path) -> bool:
    return path.suffix.lower() in {".py", ".sh", ".zsh", ".swift", ".m", ".mm", ".c", ".cc", ".cpp", ".h", ".hpp", ".cs", ".fs", ".json", ".xml", ".plist", ".xcodeproj", ".xcworkspace", ".sln", ".slnx", ".csproj", ".html", ".css", ".js", ".ts", ".tsx", ".md", ".txt", ".yml", ".yaml", ".toml", ".lua"}


def snapshot(path: Path) -> dict:
    if not path.is_file():
        return {"ok": False, "error": f"File not found: {path}"}
    raw = path.read_bytes()
    digest = hashlib.sha256(raw).hexdigest()
    stamp = datetime.datetime.now().strftime("%Y%m%d-%H%M%S-%f")
    target = BACKUP_ROOT / f"{stamp}-{digest[:12]}-{path.name.replace(' ', '_')}"
    target.write_bytes(raw)
    result = {"ok": True, "source": str(path), "snapshot": str(target), "sha256": digest, "size": len(raw)}
    log("snapshot", result)
    return result


@mcp.tool()
def omnilink_status() -> dict:
    return {"status": "online", "name": "DARK ASIRIS // OMNILINK MAC", "version": "1.0.0-macos", "platform": platform.platform(), "machine": platform.machine()}


@mcp.tool()
def mac_system_info() -> dict:
    return {"sw_vers": run("/usr/bin/sw_vers", [], timeout=20), "uname": run("/usr/bin/uname", ["-a"], timeout=20), "hardware": run("/usr/sbin/system_profiler", ["SPHardwareDataType", "SPDisplaysDataType"], timeout=60)}


@mcp.tool()
def tool_inventory() -> dict:
    names = ["git", "python3", "pip3", "node", "npm", "npx", "dotnet", "swift", "xcodebuild", "xcrun", "cmake", "make", "brew", "code"]
    return {name: shutil.which(name) for name in names}


@mcp.tool()
def list_directory(path: str) -> dict:
    target = norm(path)
    if not target.is_dir():
        return {"ok": False, "error": f"Directory not found: {target}"}
    items = []
    for item in sorted(target.iterdir(), key=lambda p: (p.is_file(), p.name.lower()))[: int(CONFIG["max_directory_items"])]:
        items.append({"name": item.name, "type": "directory" if item.is_dir() else "file", "size": item.stat().st_size if item.is_file() else None})
    return {"ok": True, "directory": str(target), "items": items}


@mcp.tool()
def read_file(path: str) -> dict:
    target = norm(path)
    if not target.is_file() or not safe_text(target):
        return {"ok": False, "error": "File missing or type not allowed"}
    if target.stat().st_size > int(CONFIG["max_read_bytes"]):
        return {"ok": False, "error": "File too large"}
    return {"ok": True, "path": str(target), "content": target.read_text(encoding="utf-8", errors="replace")}


@mcp.tool()
def write_file(path: str, content: str, overwrite: bool = False) -> dict:
    target = norm(path)
    if target.exists() and not overwrite:
        return {"ok": False, "error": "File exists; overwrite=false"}
    if target.exists():
        snapshot(target)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(content, encoding="utf-8")
    return {"ok": True, "path": str(target)}


@mcp.tool()
def search_files(path: str, pattern: str) -> dict:
    root = norm(path)
    if not root.is_dir():
        return {"ok": False, "error": "Directory not found"}
    hits = [str(p) for p in root.rglob("*") if pattern.lower() in p.name.lower()][:200]
    return {"ok": True, "count": len(hits), "results": hits}


@mcp.tool()
def git_status(project_directory: str) -> dict:
    git = shutil.which("git")
    return run(git, ["-C", str(norm(project_directory)), "status", "--short", "--branch"], timeout=30) if git else {"ok": False, "error": "git not found"}


@mcp.tool()
def git_diff(project_directory: str) -> dict:
    git = shutil.which("git")
    return run(git, ["-C", str(norm(project_directory)), "diff", "--"], timeout=60) if git else {"ok": False, "error": "git not found"}


@mcp.tool()
def discover_projects(root: str) -> dict:
    base = norm(root)
    markers = {"Package.swift", "package.json", "pyproject.toml", "requirements.txt", "CMakeLists.txt", "Cargo.toml", "go.mod"}
    hits = []
    for p in base.rglob("*"):
        if any(part in {".git", "node_modules", ".venv", "build", "DerivedData"} for part in p.parts):
            continue
        if p.name in markers or p.suffix in {".xcodeproj", ".xcworkspace", ".sln", ".slnx", ".csproj"}:
            hits.append(str(p))
        if len(hits) >= 300:
            break
    return {"ok": True, "root": str(base), "count": len(hits), "projects": hits}


@mcp.tool()
def xcode_info() -> dict:
    xcodebuild = shutil.which("xcodebuild")
    if not xcodebuild:
        return {"ok": False, "error": "xcodebuild not found"}
    return {"version": run(xcodebuild, ["-version"], timeout=30), "sdks": run(xcodebuild, ["-showsdks"], timeout=30)}


@mcp.tool()
def xcode_build(project_path: str, scheme: str, configuration: str = "Debug") -> dict:
    xcodebuild = shutil.which("xcodebuild")
    target = norm(project_path)
    if not xcodebuild or not target.exists():
        return {"ok": False, "error": "xcodebuild or project missing"}
    flag = "-workspace" if target.suffix == ".xcworkspace" else "-project"
    return run(xcodebuild, [flag, str(target), "-scheme", scheme, "-configuration", configuration, "build"], cwd=str(target.parent), timeout=900)


@mcp.tool()
def build_project(project_path: str, configuration: str = "Debug", scheme: str = "") -> dict:
    target = norm(project_path)
    if target.suffix in {".xcodeproj", ".xcworkspace"}:
        if not scheme:
            return {"ok": False, "error": "scheme required for Xcode project"}
        return xcode_build(str(target), scheme, configuration)
    if target.name == "Package.swift":
        swift = shutil.which("swift")
        return run(swift, ["build", "-c", configuration.lower()], cwd=str(target.parent), timeout=900) if swift else {"ok": False, "error": "swift not found"}
    if target.suffix in {".sln", ".slnx", ".csproj"}:
        dotnet = shutil.which("dotnet")
        return run(dotnet, ["build", str(target), "--configuration", configuration, "--nologo"], cwd=str(target.parent), timeout=900) if dotnet else {"ok": False, "error": "dotnet not found"}
    return {"ok": False, "error": "Unsupported project type"}


@mcp.tool()
def project_replace_text(path: str, old_text: str, new_text: str, expected_replacements: int = 1) -> dict:
    target = norm(path)
    if not target.is_file() or not safe_text(target):
        return {"ok": False, "error": "File missing or type not allowed"}
    content = target.read_text(encoding="utf-8", errors="replace")
    actual = content.count(old_text)
    if actual != expected_replacements:
        return {"ok": False, "error": "Replacement count mismatch", "expected": expected_replacements, "actual": actual}
    snap = snapshot(target)
    target.write_text(content.replace(old_text, new_text, expected_replacements), encoding="utf-8")
    result = {"ok": True, "path": str(target), "snapshot": snap["snapshot"], "replacements": actual}
    log("replace_text", result)
    return result


@mcp.tool()
def restore_snapshot(snapshot_path: str, destination_path: str) -> dict:
    source = norm(snapshot_path)
    destination = norm(destination_path)
    try:
        source.relative_to(BACKUP_ROOT.resolve())
    except ValueError:
        return {"ok": False, "error": "Snapshot outside OMNILINK backup root"}
    if not source.is_file():
        return {"ok": False, "error": "Snapshot not found"}
    if destination.exists():
        snapshot(destination)
    destination.write_bytes(source.read_bytes())
    return {"ok": True, "snapshot": str(source), "destination": str(destination)}


@mcp.tool()
def safe_command(command: str, arguments: list[str], working_directory: str = "", timeout: int = 120) -> dict:
    if command not in CONFIG["allowed_shell_commands"]:
        return {"ok": False, "error": "Command not allowlisted"}
    exe = shutil.which(command)
    if not exe:
        return {"ok": False, "error": f"Command not found: {command}"}
    cwd = str(norm(working_directory)) if working_directory else None
    return run(exe, arguments, cwd=cwd, timeout=max(1, min(timeout, 900)))


if __name__ == "__main__":
    mcp.run(transport="streamable-http", host="127.0.0.1", port=8000)

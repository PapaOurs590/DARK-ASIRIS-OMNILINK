DARK ASIRIS // OMNILINK MAC v1.0

INSTALLATION
1. Decompresser le ZIP dans Applications ou Documents.
2. Clic droit sur SETUP.command > Ouvrir.
3. Fournir le Tunnel ID et la Runtime API key de votre ami, jamais ceux du PC Windows.
4. Double-cliquer START-OMNILINK.command.
5. Dans ChatGPT, creer un plugin Tunnel sans authentification et choisir le tunnel du Mac.

COMPATIBILITE
- Apple Silicon : M1/M2/M3/M4/M5 (arm64)
- Mac Intel : x86_64 (amd64)
- Le setup choisit automatiquement le bon tunnel-client officiel.

SECURITE
- La cle Runtime est stockee dans le Trousseau macOS.
- Le serveur ecoute uniquement sur 127.0.0.1:8000.
- Les commandes shell sont limitees a une liste blanche.
- Les modifications de fichiers creent des snapshots.
- Chaque ami doit utiliser son propre tunnel et sa propre cle Runtime.

OUTILS PRINCIPAUX
- systeme macOS, fichiers, recherche
- Git
- detection Python/Node/.NET/Swift/Xcode/CMake/Homebrew
- decouverte et build Xcode, Swift Package et .NET
- remplacements controles, snapshots et restauration
- commandes autorisees uniquement

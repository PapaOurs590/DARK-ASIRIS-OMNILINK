#!/bin/zsh
set -euo pipefail
cd "$(dirname "$0")"
ROOT="$PWD"
ARCH="$(uname -m)"
case "$ARCH" in
  arm64) ASSET_ARCH="arm64" ;;
  x86_64) ASSET_ARCH="amd64" ;;
  *) echo "Architecture non supportee: $ARCH"; exit 1 ;;
esac
command -v python3 >/dev/null || { echo "Installe Python 3 puis relance."; exit 1; }
python3 -m venv .venv
.venv/bin/python -m pip install --upgrade pip
.venv/bin/pip install -r requirements.txt
mkdir -p tunnel logs backup config
API="https://api.github.com/repos/openai/tunnel-client/releases/latest"
ASSET_URL="$(curl -fsSL "$API" | python3 -c 'import json,sys; d=json.load(sys.stdin); arch=sys.argv[1]; print(next(a["browser_download_url"] for a in d["assets"] if a["name"].startswith("tunnel-client-v") and a["name"].endswith("darwin-"+arch+".zip")))' "$ASSET_ARCH")"
curl -fL "$ASSET_URL" -o tunnel/tunnel-client.zip
rm -rf tunnel/extracted && mkdir -p tunnel/extracted
/usr/bin/ditto -x -k tunnel/tunnel-client.zip tunnel/extracted
BIN="$(find tunnel/extracted -type f -name tunnel-client | head -n 1)"
[ -n "$BIN" ] || { echo "Binaire tunnel-client introuvable"; exit 1; }
cp "$BIN" tunnel/tunnel-client
chmod +x tunnel/tunnel-client START-OMNILINK.command STOP-OMNILINK.command
printf "Tunnel ID OpenAI: "
read TUNNEL_ID
printf "Nom du profil [dark-asiris-omnilink-mac]: "
read PROFILE
PROFILE="${PROFILE:-dark-asiris-omnilink-mac}"
./tunnel/tunnel-client init --profile "$PROFILE" --tunnel-id "$TUNNEL_ID" --mcp-server-url "http://127.0.0.1:8000/mcp"
printf "Runtime API key OpenAI (saisie masquee): "
read -s RUNTIME_KEY
echo
security add-generic-password -U -a "$USER" -s "DARK_ASIRIS_OMNILINK_RUNTIME_KEY" -w "$RUNTIME_KEY"
printf '%s\n' "$PROFILE" > config/profile-name.txt
echo "Installation terminee. Double-clique START-OMNILINK.command"
